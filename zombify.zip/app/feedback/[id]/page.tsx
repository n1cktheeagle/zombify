// app/feedback/[id]/page.tsx
import { createSupabaseServerClient } from '@/lib/supabase';
import { notFound } from 'next/navigation';

export default async function FeedbackPage({ params }: { params: { id: string } }) {
  const supabase = createSupabaseServerClient();

  const { data, error } = await supabase
    .from('feedback')
    .select('*')
    .eq('id', params.id)
    .single();

  if (error || !data) {
    notFound(); // shows Next.js 404 page
  }

  return (
    <div className="p-10">
      <h1 className="text-2xl font-bold">Feedback Result</h1>
      <p className="mt-2">Project: {data.project_name}</p>
      <p className="mt-2">Score: {data.analysis?.score}</p>
      <p className="mt-2">Issues:</p>
      <ul className="list-disc ml-5">
        {data.analysis?.issues?.map((issue: string, i: number) => (
          <li key={i}>{issue}</li>
        ))}
      </ul>
      <img
        src={data.image_url}
        alt="Screenshot"
        className="mt-6 border rounded max-w-md"
      />
    </div>
  );
}