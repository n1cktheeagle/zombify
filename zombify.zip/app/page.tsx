'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function HomePage() {
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const router = useRouter();

  async function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    setError('');

    const formData = new FormData();
    formData.append('file', file);
    formData.append('project_name', 'Untitled');

    const res = await fetch('/api/upload', {
      method: 'POST',
      body: formData,
    });

    if (!res.ok) {
      const err = await res.json();
      setError(err.error || 'Upload failed');
      setUploading(false);
      return;
    }

    // Follow redirect to feedback page
    if (res.redirected) {
      router.push(res.url);
    } else {
      setError('Unexpected response from server');
      setUploading(false);
    }
  }

  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-zinc-100 px-4">
      <h1 className="text-4xl font-bold mb-6 text-center">Zombify your design</h1>

      <label className="cursor-pointer bg-black text-white px-6 py-3 rounded-md hover:bg-zinc-800 transition-all">
        {uploading ? 'Uploading...' : 'Upload Screenshot'}
        <input
          type="file"
          name="file"
          accept="image/*"
          onChange={handleFileChange}
          className="hidden"
          disabled={uploading}
        />
      </label>

      {error && <p className="text-red-500 mt-4">{error}</p>}
    </main>
  );
}