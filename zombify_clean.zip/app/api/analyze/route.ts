import { NextResponse } from "next/server"
import path from "path"
import { nanoid } from "nanoid"
import { OpenAI } from "openai"

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY!,
})

export async function POST(request: Request) {
  const formData = await request.formData()
  const file = formData.get("image") as File

  if (!file) {
    return NextResponse.json({ error: "No file uploaded" }, { status: 400 })
  }

  const buffer = Buffer.from(await file.arrayBuffer())
  const base64Image = buffer.toString("base64")

  const visionResponse = await openai.chat.completions.create({
    model: "gpt-4o", // Updated model name from deprecated one
    max_tokens: 1000,
    messages: [
      {
        role: "system",
        content:
          "You're a senior product designer. Given this screenshot, give clear, structured UX feedback with bullet points and specific action steps.",
      },
      {
        role: "user",
        content: [
          {
            type: "image_url",
            image_url: {
              url: `data:image/png;base64,${base64Image}`,
            },
          },
        ],
      },
    ],
  })

  const feedbackText = visionResponse.choices[0].message.content || ""
  const id = nanoid()

  // Simulate parsed feedback structure
  const feedbackData = {
    id,
    image: `data:image/png;base64,${base64Image}`,
    feedback: feedbackText,
    gripScore: Math.floor(Math.random() * 100),
    highlights: [
      { title: "Visual Hierarchy", description: "Clear structure and flow." },
      { title: "Spacing", description: "Good use of padding and margins." },
    ],
    radar: {
      clarity: 7,
      alignment: 8,
      accessibility: 6,
      usability: 7,
      aesthetics: 9,
    },
  }

  globalThis.__zombifyData = globalThis.__zombifyData || {}
  globalThis.__zombifyData[id] = feedbackData

  const origin = new URL(request.url).origin
  return NextResponse.redirect(`${origin}/feedback/${id}`)
}