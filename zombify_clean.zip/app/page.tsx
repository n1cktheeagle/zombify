
"use client"
import { useRef } from "react"

export default function Home() {
  const formRef = useRef<HTMLFormElement>(null)

  const handleFileChange = () => {
    formRef.current?.submit()
  }

  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-[#f5f1e8] text-black p-6">
      <h1 className="text-4xl font-bold mb-4">Zombify Your Design</h1>
      <p className="mb-6 text-center max-w-md">Upload a screenshot and receive undead insights into your UI’s weaknesses.</p>

      <form
        ref={formRef}
        action="/api/analyze"
        method="POST"
        encType="multipart/form-data"
        className="space-y-4"
      >
        <input
          type="file"
          name="image"
          accept="image/*"
          onChange={handleFileChange}
          className="block text-sm text-black file:mr-4 file:py-2 file:px-4 file:border-0 file:bg-black file:text-white hover:file:bg-black/80"
        />
      </form>
    </main>
  )
}
