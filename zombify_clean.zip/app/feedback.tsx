// app/feedback/page.tsx
import { createServerClient } from '@/lib/supabase/server';
import { getCookies } from '@/lib/supabase/cookies';
import FeedbackResults from '@/components/FeedbackResults';
import { notFound } from 'next/navigation';

export default async function FeedbackPage({ searchParams }: { searchParams: { id?: string } }) {
  const cookieStore = await getCookies();
  const supabase = createServerClient();

  const { data: feedback, error } = await supabase
    .from('feedback')
    .select('*')
    .eq('id', searchParams.id)
    .single();

  if (error || !feedback) {
    return (
      <div className="text-red-500 text-center mt-10 text-xl">
        Error loading feedback
      </div>
    );
  }

  return <FeedbackResults feedback={feedback} />;
}
