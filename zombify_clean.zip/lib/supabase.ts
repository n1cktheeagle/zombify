export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json }
  | Json[];

export interface Database {
  public: {
    Tables: {
      feedback: {
        Row: {
          id: string;
          created_at: string;
          image_url: string;
          grip_score: number;
          feedback_chunks: Json;
          project_id: string;
        };
        Insert: {
          id?: string;
          created_at?: string;
          image_url: string;
          grip_score: number;
          feedback_chunks: Json;
          project_id: string;
        };
        Update: {
          id?: string;
          created_at?: string;
          image_url?: string;
          grip_score?: number;
          feedback_chunks?: Json;
          project_id?: string;
        };
      };
    };
    Views: {};
    Functions: {};
    Enums: {};
    CompositeTypes: {};
  };
}