'use client';

import GripScoreCard from './GripScoreCard';
import AdviceList from './AdviceList';

type FeedbackResultsProps = {
  score: number;
  advice: {
    title: string;
    description: string;
  }[];
};

export default function FeedbackResults({ score, advice }: FeedbackResultsProps) {
  return (
    <div className="max-w-2xl mx-auto py-10 space-y-6">
      <GripScoreCard score={score} />
      <AdviceList items={advice} />
    </div>
  );
}